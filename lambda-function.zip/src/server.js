"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const app_1 = require("./app");
const config_1 = require("./config");
const startServer = () => {
    (0, config_1.logEnvironment)();
    app_1.app.listen(app_1.PORT, () => {
        console.log(`Server running, listening on Port ${app_1.PORT}`);
    });
};
startServer();
//# sourceMappingURL=server.js.map