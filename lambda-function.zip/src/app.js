"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = exports.PORT = void 0;
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const graphql_yoga_1 = require("graphql-yoga");
const schema_1 = require("./graphql/schema");
const config_1 = require("./config");
exports.PORT = config_1.CURRENT_CONFIG.port;
// Initialize the Express app
exports.app = (0, express_1.default)();
exports.app.use(express_1.default.json());
exports.app.use((0, cors_1.default)({
    origin: config_1.CURRENT_CONFIG.corsOrigin,
}));
// Request logging middleware
exports.app.use("/", (req, res, next) => {
    const datetime = new Date().toISOString().slice(0, -5) + "Z";
    console.log(`\x1b[1;33m[${datetime}] ${config_1.CURRENT_CONFIG.environment}\x1b[0m`);
    console.log(`METHOD: ${req.method}`);
    console.log(`URL: ${req.url}`);
    console.log(`HEADERS: ${JSON.stringify(req.headers, null, 2)}`);
    console.log(`BODY: ${JSON.stringify(req.body, null, 2)}`);
    next();
});
// GraphQL Yoga setup
const yoga = (0, graphql_yoga_1.createYoga)({
    schema: schema_1.schema,
    parserAndValidationCache: false,
    plugins: [
        {
            onExecute: ({ args }) => {
                console.log(`📡 GraphQL request in ${config_1.CURRENT_CONFIG.environment} environment`);
            },
            onResultProcess: ({ result }) => {
                // A place to log info about post-graphql operations
            },
        },
    ],
});
// Mount GraphQL endpoint
exports.app.use("/graphql", yoga);
// Health check endpoint
exports.app.get("/health", (req, res) => {
    res.json({
        status: "ok",
        environment: config_1.CURRENT_CONFIG.environment,
        timestamp: new Date().toISOString(),
    });
});
//# sourceMappingURL=app.js.map