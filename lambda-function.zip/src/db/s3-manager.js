"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isS3Active = exports.initializeS3Storage = exports.syncDBToS3 = exports.getDBPath = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const fs_1 = require("fs");
const path_1 = __importDefault(require("path"));
// S3 client instance (lazy initialization)
let s3Client = null;
// Environment check
const isS3Enabled = () => {
    const deploymentEnv = process.env.DEPLOYMENT_ENV || process.env.NODE_ENV;
    return deploymentEnv === 'aws-lambda' || deploymentEnv === 'production';
};
// Get the appropriate db.json path based on environment
const getDBPath = () => {
    if (isS3Enabled()) {
        return '/tmp/db.json';
    }
    // Localhost: relative to this file's location
    return path_1.default.join(__dirname, 'json/db.json');
};
exports.getDBPath = getDBPath;
// Initialize S3 client
const getS3Client = () => {
    if (!s3Client) {
        s3Client = new client_s3_1.S3Client({
            region: process.env.AWS_REGION || 'us-east-1',
        });
    }
    return s3Client;
};
// Download db.json from S3 to /tmp
const downloadFromS3 = async () => {
    const bucketName = process.env.S3_BUCKET_NAME;
    if (!bucketName) {
        throw new Error('S3_BUCKET_NAME environment variable is not set');
    }
    console.log(`Downloading db.json from S3 bucket: ${bucketName}`);
    const client = getS3Client();
    const command = new client_s3_1.GetObjectCommand({
        Bucket: bucketName,
        Key: 'db.json',
    });
    try {
        const response = await client.send(command);
        if (!response.Body) {
            throw new Error('S3 response body is empty');
        }
        // Convert stream to string
        const bodyString = await response.Body.transformToString();
        // Write to /tmp
        (0, fs_1.writeFileSync)('/tmp/db.json', bodyString, 'utf-8');
        console.log('✓ Successfully downloaded db.json from S3');
    }
    catch (error) {
        console.error('Failed to download db.json from S3:', error);
        throw error;
    }
};
// Upload db.json from /tmp to S3
const syncDBToS3 = async () => {
    if (!isS3Enabled()) {
        // Not in Lambda environment, skip S3 sync
        return;
    }
    const bucketName = process.env.S3_BUCKET_NAME;
    if (!bucketName) {
        console.error('S3_BUCKET_NAME not set, skipping S3 sync');
        return;
    }
    const dbPath = '/tmp/db.json';
    if (!(0, fs_1.existsSync)(dbPath)) {
        console.error('db.json not found in /tmp, skipping S3 sync');
        return;
    }
    try {
        const fileContent = (0, fs_1.readFileSync)(dbPath, 'utf-8');
        const client = getS3Client();
        const command = new client_s3_1.PutObjectCommand({
            Bucket: bucketName,
            Key: 'db.json',
            Body: fileContent,
            ContentType: 'application/json',
        });
        await client.send(command);
        console.log('✓ Successfully synced db.json to S3');
    }
    catch (error) {
        console.error('Failed to sync db.json to S3:', error);
        // Don't throw - we don't want to fail the request if S3 sync fails
        // Data is still written to /tmp, just not persisted
    }
};
exports.syncDBToS3 = syncDBToS3;
// Initialize S3 storage (download db.json if needed)
const initializeS3Storage = async () => {
    if (!isS3Enabled()) {
        console.log('Not in Lambda environment, skipping S3 initialization');
        return;
    }
    const dbPath = '/tmp/db.json';
    // Check if db.json already exists in /tmp (warm start)
    if ((0, fs_1.existsSync)(dbPath)) {
        console.log('Using cached db.json from /tmp (warm start)');
        return;
    }
    // Cold start: download from S3
    console.log('Cold start: downloading db.json from S3');
    await downloadFromS3();
};
exports.initializeS3Storage = initializeS3Storage;
// Check if S3 manager is active
const isS3Active = () => {
    return isS3Enabled();
};
exports.isS3Active = isS3Active;
//# sourceMappingURL=s3-manager.js.map