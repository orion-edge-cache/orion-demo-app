/**
 * Local development server
 * Run with: npm run dev
 */
export {};
//# sourceMappingURL=server.d.ts.map