/**
 * GraphQL Yoga instance
 *
 * Shared by both Lambda handler and Express server.
 * This file should have minimal dependencies to keep Lambda cold starts fast.
 */
export declare const yoga: import("graphql-yoga").YogaServerInstance<{}, {}>;
//# sourceMappingURL=yoga.d.ts.map