/**
 * GraphQL schema definition
 */
export declare const schema: import("graphql-yoga").GraphQLSchemaWithContext<import("graphql-yoga").YogaInitialContext>;
//# sourceMappingURL=schema.d.ts.map