"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const config = {
    overwrite: true,
    schema: "src/graphql/schema.graphql",
    generates: {
        "src/graphql/resolvers-types.ts": {
            plugins: ["typescript", "typescript-resolvers"]
        }
    }
};
exports.default = config;
//# sourceMappingURL=codegen.js.map