/**
 * Express app for local development
 *
 * This file is NOT loaded in Lambda - only yoga.ts is used there.
 * Run locally with: npm run dev
 */
export declare const PORT: number;
export declare const app: import("express-serve-static-core").Express;
//# sourceMappingURL=app.d.ts.map