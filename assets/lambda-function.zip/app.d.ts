/**
 * Express application with GraphQL Yoga
 */
export declare const PORT: number;
export declare const app: import("express-serve-static-core").Express;
//# sourceMappingURL=app.d.ts.map