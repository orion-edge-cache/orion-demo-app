/**
 * AWS Lambda handler for the demo app
 */
import type { Context } from 'aws-lambda';
export declare const handler: (event: Record<string, unknown>, context: Context) => Promise<unknown>;
//# sourceMappingURL=lambda-handler.d.ts.map