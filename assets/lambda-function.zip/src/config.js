"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logEnvironment = exports.CURRENT_CONFIG = exports.CONFIG = exports.DEPLOYMENT_ENV = void 0;
const isValidEnv = (env) => {
    return ['aws-lambda', 'localhost'].includes(env);
};
const getDeploymentEnv = () => {
    // Priority 1: Explicit DEPLOYMENT_ENV variable
    const explicit = process.env.DEPLOYMENT_ENV;
    if (explicit && isValidEnv(explicit)) {
        return explicit;
    }
    // Priority 2: NODE_ENV mapping (fallback)
    const nodeEnv = process.env.NODE_ENV;
    if (nodeEnv === 'production') {
        return 'aws-lambda';
    }
    // Default to localhost
    return 'localhost';
};
// Build config from environment variables with defaults
const buildConfig = () => ({
    'aws-lambda': {
        port: 0, // Not used in Lambda
        corsOrigin: process.env.CORS_ORIGIN || '*', // CORS handled by API Gateway
        environment: 'aws-lambda',
    },
    localhost: {
        port: parseInt(process.env.LOCALHOST_PORT || '3002', 10),
        corsOrigin: 'http://localhost:5173',
        environment: 'localhost',
    }
});
exports.DEPLOYMENT_ENV = getDeploymentEnv();
exports.CONFIG = buildConfig();
exports.CURRENT_CONFIG = exports.CONFIG[exports.DEPLOYMENT_ENV];
// Log detected environment
const logEnvironment = () => {
    console.log(`🚀 Server starting in ${exports.DEPLOYMENT_ENV} environment`);
    console.log(`📍 CORS Origin: ${exports.CURRENT_CONFIG.corsOrigin}`);
};
exports.logEnvironment = logEnvironment;
//# sourceMappingURL=config.js.map